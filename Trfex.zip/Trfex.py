from math import ceil, floor
import argparse
import os

parser = argparse.ArgumentParser(description='tRF Extractor Script')
parser.add_argument('--input', help="Input tRNA secondary structure (.ss) file")
parser.add_argument('--output', help="Output directory name or path")
parser.add_argument('--score', help="Get best score only for each isotype ('yes', 'no'); default='no'")
args = parser.parse_args()

hiScoreKey = 1
if args.score == 'yes':
    hiScoreKey = 0
elif args.score == 'no':
    hiScoreKey = 1
else:
    hiScoreKey = 1

trnaSS = args.input
with open(trnaSS, 'r+') as ref:
    readref = ref.read()
    splitref = readref.split('\n\n')

if hiScoreKey == 0:
    isotypes = []
    uniqueIsotypes = []
    for fd, f in enumerate(filter(None, splitref)):
        isotypes.append('%s %s'%(f.split('\n')[1].split('\t')[0].replace('Type: ', ''), f.split('\n')[1].split('\t')[1].replace('Anticodon: ', '').split(' ')[0]))
    uniqueIsotypes = sorted(set(isotypes))

    hiScore = []
    for ad, a in enumerate(uniqueIsotypes):
        scores = []
        indexes = []
        for fd, f in enumerate(filter(None, splitref)):
            HiScore = float(f.split('\n')[1].split(' ')[-1])
            HiAminoAcid = f.split('\n')[1].split('\t')[0].replace('Type: ', '')
            HiAnticodon = f.split('\n')[1].split('\t')[1].replace('Anticodon: ', '').split(' ')[0]
            if a == '%s %s'%(HiAminoAcid,HiAnticodon):
                scores.append(HiScore)
                indexes.append(fd)
        hiScore.append(indexes[scores.index(max(scores))])
else:
    pass

gtftrf5a = []
gtftrf5b = []
gtftrf5c = []
gtftirna5 = []
gtfitrf = []
gtftrf2 = []
gtftirna3 = []
gtftrf3b = []
gtftrf3a = []

missed = []
trfs = []

for ld, l in enumerate(filter(None, splitref)):
    if hiScoreKey == 0:
        if ld in hiScore:
            pass
        else:
            continue
    loops = []
    startEnd = l.split('\n')[0].split(' ')[1].replace('(', '').replace(')', '').split('-')
    trnaStart = min(int(startEnd[0]), int(startEnd[1].split('\t')[0]))
    trnaEnd = max(int(startEnd[0]), int(startEnd[1].split('\t')[0]))
    strand = '+'
    if int(startEnd[0]) > int(startEnd[1].split('\t')[0]):
        strand = '-'
    fullTrnaName = l.split('\n')[0].split(' ')[0]
    trnaName = l.split('\n')[0].split(' ')[0].split('.trna')[0]
    aminoAcid = l.split('\n')[1].split('\t')[0].replace('Type: ', '')
    anticodon = l.split('\n')[1].split('\t')[1].replace('Anticodon: ', '').split(' ')[0]
    predictedTrnaseq = l.split('\n')[-1].replace('Str: ', '')
    trnaseq = l.split('\n')[-2].replace('Seq: ', '')
    ignoredPoses = []
    loopsStart = []
    loopsEnd = []
    countLoops = 0
    for id, i in enumerate(predictedTrnaseq):
        if id not in ignoredPoses:
            if i == '.':
                if len(predictedTrnaseq[id:id+3]) >= 3 and predictedTrnaseq[id+1] == '.' and predictedTrnaseq[id+2] == '.':
                    if predictedTrnaseq[id-1] == '>' or predictedTrnaseq[id-1] == '<':
                        loopLen = 0
                        for kd, k in enumerate(predictedTrnaseq[id+1:]):
                            if k == '>' or k == '<':
                                if k != predictedTrnaseq[id-1]:
                                    loopLen = kd
                                    countLoops += 1
                                    loopsStart.append(id)
                                    break
                                else:
                                    break
                            else:
                                ignoredPoses.append(id+1+kd)
                        for jd, j in enumerate(predictedTrnaseq[:id][::-1]):
                            if j == '.':
                                loops.append([id,id + loopLen])
                                break
    if len(loops) == 4:
        Dloop = loops[0]
        anticodonLoop = loops[1]
        valiableLoop = loops[2]
        Tloop = loops[3]
        
        trf5a = trnaseq[ 0 : floor ( Dloop[1] - ( ( Dloop[1] - Dloop[0] ) / 2 ) ) ]
        trf5aintervals = [ trnaStart + 0, trnaStart + (floor ( Dloop[1] - ( ( Dloop[1] - Dloop[0] ) / 2 ) ) ) - 1 ]
        gtftrf5a.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', trf5aintervals[0], trf5aintervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-tRF-5a";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-tRF-5a-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, trf5a))

        trf5b = trnaseq[ 0 : floor( Dloop[1] + ( ( anticodonLoop[0] - Dloop[1] ) / 3 ) ) + 1 ]
        trf5bintervals = [ trnaStart + 0, trnaStart + floor( Dloop[1] + ( ( anticodonLoop[0] - Dloop[1] ) / 3 ) )]
        gtftrf5b.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', trf5bintervals[0], trf5bintervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-tRF-5b";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-tRF-5b-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, trf5b))

        trf5c = trnaseq[ 0 : floor( anticodonLoop[0] - ( ( anticodonLoop[0] - Dloop[1] ) / 3 ) ) + 1 ]
        trf5cintervals = [ trnaStart + 0 , trnaStart + floor( anticodonLoop[0] - ( ( anticodonLoop[0] - Dloop[1] ) / 3 ) ) ]
        gtftrf5c.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', trf5cintervals[0], trf5cintervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-tRF-5c";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-tRF-5c-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, trf5c))

        tirna5 = trnaseq[ 0 : floor ( anticodonLoop[0] + ( ( anticodonLoop[1] - anticodonLoop[0] ) / 2 ) ) ]
        tirna5intervals = [ trnaStart + 0 , trnaStart + floor ( anticodonLoop[0] + ( ( anticodonLoop[1] - anticodonLoop[0] ) / 2 ) ) - 1 ]
        gtftirna5.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', tirna5intervals[0], tirna5intervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-5`tiRNA";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-5`tiRNA-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, tirna5))

        itrna = trnaseq[ floor ( Dloop[1] - ( ( Dloop[1] - Dloop[0] ) / 2 ) ) + 1 : floor ( Tloop[1] - ( ( Tloop[1] - Tloop[0] ) / 2 ) ) ]
        itrnaintervals = [ trnaStart + floor ( Dloop[1] - ( ( Dloop[1] - Dloop[0] ) / 2 ) ) + 1, trnaStart + floor ( Tloop[1] - ( ( Tloop[1] - Tloop[0] ) / 2 ) ) - 1 ]
        gtfitrf.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', itrnaintervals[0], itrnaintervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-i-tRF";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-i-tRF-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, itrna))

        trf2 = trnaseq[ ceil ( Dloop[1] + ( ( anticodonLoop[0] - Dloop[1] ) / 2 ) ) : valiableLoop[0] ]
        trf2intervals = [ trnaStart + ceil ( Dloop[1] + ( ( anticodonLoop[0] - Dloop[1] ) / 2 ) ), trnaStart + valiableLoop[0] - 1]
        gtftrf2.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', trf2intervals[0], trf2intervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-tRF-2";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-tRF-2-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, trf2))

        tirna3 = trnaseq[floor ( anticodonLoop[1] - ( ( anticodonLoop[1] - anticodonLoop[0] ) / 2 ) ) + 1 : ]
        tirna3intervals = [ trnaStart + floor ( anticodonLoop[1] - ( ( anticodonLoop[1] - anticodonLoop[0] ) / 2 ) ) + 1, trnaEnd]
        gtftirna3.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', tirna3intervals[0], tirna3intervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-3`tiRNA";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-3`tiRNA-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, tirna3))

        trf3b = trnaseq[ Tloop[0] + floor ( ( Tloop[1] - Tloop[0] ) / 3 ) : ]
        trf3bintervals = [ trnaStart + Tloop[0] + floor ( ( Tloop[1] - Tloop[0] ) / 3 ), trnaEnd ]
        gtftrf3b.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', trf3bintervals[0], trf3bintervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-tRF-3b";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-tRF-3b-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, trf3b))

        trf3a = trnaseq[ Tloop[1] - ( floor ( ( Tloop[1] - Tloop[0] ) / 3 ) - 1 ) : ]
        trf3aintervals = [ trnaStart + Tloop[1] - ( floor ( ( Tloop[1] - Tloop[0] ) / 3 ) - 1 ), trnaEnd]
        gtftrf3a.append('%s\t%s\t%s\t%i\t%i\t%s\t%s\t%s\t%s'%(trnaName, 'Trfex', 'tsRNA', trf3aintervals[0], trf3aintervals[1], '0',strand, '.', 'gene_id "%s-%s-%s-tRF-3a";'%(fullTrnaName,aminoAcid,anticodon)))
        trfs.append('>%s-tRF-3a-%s-%s\n%s'%(trnaName, aminoAcid, anticodon, trf3a))

    else:
        missed.append(fullTrnaName)

outDir = args.output
try:
    os.mkdir(outDir)
    os.chdir(outDir)
except FileExistsError:
    os.chdir(outDir)

with open('Trfex-tRF-5a.gtf', 'w+') as w:
    w.write('\n'.join(gtftrf5a))

with open('Trfex-tRF-5b.gtf', 'w+') as w:
    w.write('\n'.join(gtftrf5b))

with open('Trfex-tRF-5c.gtf', 'w+') as w:
    w.write('\n'.join(gtftrf5c))

with open('Trfex-5tiRNA.gtf', 'w+') as w:
    w.write('\n'.join(gtftirna5))

with open('Trfex-i-tRF.gtf', 'w+') as w:
    w.write('\n'.join(gtfitrf))

with open('Trfex-tRF-2.gtf', 'w+') as w:
    w.write('\n'.join(gtftrf2))

with open('Trfex-3tiRNA.gtf', 'w+') as w:
    w.write('\n'.join(gtftirna3))

with open('Trfex-tRF-3b.gtf', 'w+') as w:
    w.write('\n'.join(gtftrf3b))

with open('Trfex-tRF-3a.gtf', 'w+') as w:
    w.write('\n'.join(gtftrf3a))

with open('Trfex-tRFs-seq.fasta', 'w+') as w:
    w.write('\n'.join(trfs))

with open('Trfex-missing.txt', 'w+') as w:
    w.write('\n'.join(missed))
